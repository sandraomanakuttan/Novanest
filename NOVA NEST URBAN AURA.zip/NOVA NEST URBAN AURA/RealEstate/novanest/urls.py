from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),  # Ensure this is correctly defined
    path('properties/', views.property_list, name='property_list'),
    path('properties/new/', views.property_form, name='property_form'),
    path('properties/create/', views.property_create, name='property_create'),
    path('properties/<int:pk>/delete/', views.delete_property, name='delete_property'),
    # Other paths as needed
]
