from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from .forms import UserRegistrationForm, PropertyForm  # Import your custom forms
from .models import Property  
from .forms import PropertyForm# Import your models

def home(request):
    return render(request, 'novanest/home.html')

@login_required
def property_list(request):
    properties = Property.objects.all()
    return render(request, 'novanest/property_list.html', {'properties': properties})

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            
            # Debug: Check user creation details
            print(f"Created User: {username}")
            
            user = authenticate(username=username, password=raw_password)
            if user:
                login(request, user)
                return redirect('property_list')
    else:
        form = UserCreationForm()
    return render(request, 'novanest/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        # Debug: Print entered username and password (Be careful with logging passwords in production)
        print(f"Username: {username}")
        print(f"Password: {password}")
        
        user = authenticate(request, username=username, password=password)
        
        # Debug: Check if user is authenticated
        if user:
            print(f"Authenticated User: {user.username}")
        else:
            print("Authentication failed")
        
        if user is not None:
            login(request, user)
            return redirect(reverse('property_list'))  # Redirect to property_list page
        else:
            # Invalid login
            return render(request, 'novanest/login.html', {'error': 'Invalid username or password'})
    return render(request, 'novanest/login.html')


@login_required
def property_create(request):
    if request.method == 'POST':
        form = PropertyForm(request.POST, request.FILES)
        if form.is_valid():
            new_property = form.save(commit=False)
            new_property.owner = request.user
            new_property.save()
            return redirect('property_list')
    else:
        form = PropertyForm()
    return render(request, 'novanest/property_form.html', {'form': form})




def property_list(request):
    properties = Property.objects.all()
    return render(request, 'novanest/property_list.html', {'properties': properties})

def property_form(request):
    if request.method == 'POST':
        form = PropertyForm(request.POST, request.FILES)
        if form.is_valid():
            property = form.save(commit=False)
            property.owner = request.user  # Set the owner to the currently logged-in user
            property.save()
            return redirect('property_list')  # Ensure this matches your URL pattern name
    else:
        form = PropertyForm()
    return render(request, 'novanest/property_form.html', {'form': form})

@login_required
def delete_property(request, pk):
    property = get_object_or_404(Property, pk=pk)
    if request.method == 'POST':
        if property.image:
            property.image.delete()
        property.delete()
        return redirect('property_list')
    return render(request, 'novanest/delete_property.html', {'property': property})
