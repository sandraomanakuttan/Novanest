from django.apps import AppConfig


class NovanestConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'novanest'
