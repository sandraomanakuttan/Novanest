from django.shortcuts import render
from .models import UrbanProperty

def urban_property_list(request):
    properties = UrbanProperty.objects.all()
    return render(request, 'urbanaura/urban_property_list.html', {'properties': properties})
