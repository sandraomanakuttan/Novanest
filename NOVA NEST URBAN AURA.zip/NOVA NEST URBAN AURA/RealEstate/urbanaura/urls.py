from django.urls import path
from . import views

urlpatterns = [
    path('', views.urban_property_list, name='urban_property_list'),
]
